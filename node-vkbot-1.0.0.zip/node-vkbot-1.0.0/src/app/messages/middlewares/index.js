'use strict';

module.exports = require('../helpers/get-files-in-dir')(__dirname);