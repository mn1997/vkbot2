
> Chat-bots on vk.com →
> [Чат-боты](https://vk.com/botsforchats) &nbsp;&middot;&nbsp;
> [Список команд](https://vk.com/page-110327182_51316051) &nbsp;&middot;&nbsp;
> [FAQ](https://vk.com/page-110327182_51827803)


## Установка
    $ git clone https://github.com/olnaz/node-vkbot.git
      cd node-vkbot
      npm i
